package br.com.tecban.CadastroUnificado;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CadastroUnificadoApplicationTests {

	@Test
	void contextLoads() {
	}

}
